DELETE	FROM	new_table	WHERE	table_a2='col2';
SELECT	*	FROM	new_table;