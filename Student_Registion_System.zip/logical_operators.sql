SELECT	student_id
FROM	student
WHERE	(student_id<5);
SELECT	*	FROM	student;