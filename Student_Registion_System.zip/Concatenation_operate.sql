SELECT	student_id,email,phone_number
FROM	student
WHERE	student_id	IN(3)