SELECT	*	FROM	new_table;
