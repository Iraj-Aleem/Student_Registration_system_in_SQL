use	shop;
SELECT	Itemno
FROM	Item
WHERE	Item	LIKE	'%$I';