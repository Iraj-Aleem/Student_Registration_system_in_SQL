UPDATE	new_table
SET	table_id=3
WHERE	table_id=1;
SELECT	*	FROM	new_table;