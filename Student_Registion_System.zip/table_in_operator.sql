SELECT	table_id,table_a1,table_a2
FROM	new_table
WHERE	table_id	IN(3)
