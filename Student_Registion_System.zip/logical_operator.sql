SELECT	table_id
FROM	new_table
WHERE	(table_id<4);
SELECT	*	FROM	new_table;