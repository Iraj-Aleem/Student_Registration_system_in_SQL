use	student_registration_system;
SELECT	*	FROM	student;