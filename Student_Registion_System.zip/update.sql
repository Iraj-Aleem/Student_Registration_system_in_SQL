use	student_registration_system;
UPDATE	student
SET	student_id=6
WHERE	student_id=1;
DELETE	FROM	student	WHERE	email='irajaleem@gmail.com';