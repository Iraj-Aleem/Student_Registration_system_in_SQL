use test;
create table faculty(FID int Primary Key, Fname varchar(20) Not Null, Faddress varchar(30));
ALTER TABLE faculty;
ALTER TABLE faculty ADD(faculty_Subject VARCHAR(20));
ALTER TABLE faculty MODIFY(faculty_Subject VARCHAR(20));
ALTER TABLE faculty Drop(faculty_Subject VARCHAR(20); 




