use	shop;
SELECT	Itemno	,Orderno	,qtynumber
FROM	Order_Item
WHERE	(Orderno>3)
;