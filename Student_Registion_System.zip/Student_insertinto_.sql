use	student_registration_system;
Create	table	student(SID	int	Primary	key,Sname	varchar(20)	Not	NULL,Saddress	varchar(30),dob	datetime,email	varchar(40));
DESC	student;
INSERT	INTO	student(SID,Sname,Saddress,dob,email)
values(019,'Iraj','COMSATS,Wah','2003-04-2','irajaleem@gmail.com');
