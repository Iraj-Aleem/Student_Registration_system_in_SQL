use	new_database;
CREATE	table	new_table(
table_id	int	primary	key,
table_a1	varchar(20)	NOT	NULL,
table_a2	varchar(30),
t_creation_date	datetime
);
DESC	new_table;