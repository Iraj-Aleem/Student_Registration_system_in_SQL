
CREATE TABLE Faculty (
  faculty_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,
  department VARCHAR(50),
  email VARCHAR(50) NOT NULL,
  phone_number VARCHAR(20)
);
