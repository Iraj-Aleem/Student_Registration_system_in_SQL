#5
use	shop;
UPDATE	Cust_Order
SET	Ord_amt=6
WHERE	Ord_amt=2

